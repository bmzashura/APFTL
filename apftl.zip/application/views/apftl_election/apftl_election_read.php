<div class="container-fluid">
	<h2 style="margin-top:0px">Apftl_election Read</h2>
	<table class="table">
		<tr>
			<td>Id Distric</td>
			<td><?php echo $distric; ?></td>
		</tr>
		<tr>
			<td>Id Subdistric</td>
			<td><?php echo $subdistric; ?></td>
		</tr>
		<tr>
			<td>Election Period</td>
			<td><?php echo $election_period; ?></td>
		</tr>
		<tr>
			<td>Female Register</td>
			<td><?php echo $female_register; ?></td>
		</tr>
		<tr>
			<td>Male Register</td>
			<td><?php echo $male_register; ?></td>
		</tr>
		<tr>
			<td>Total Register</td>
			<td><?php echo $total_register; ?></td>
		</tr>
		<tr>
			<td>Female Selected</td>
			<td><?php echo $female_selected; ?></td>
		</tr>
		<tr>
			<td>Male Selected</td>
			<td><?php echo $male_selected; ?></td>
		</tr>
		<tr>
			<td>Total Selected</td>
			<td><?php echo $total_selected; ?></td>
		</tr>
		<tr>
			<td>Female Candidate</td>
			<td><?php echo $female_candidate; ?></td>
		</tr>
		<tr>
			<td>Male Candidate</td>
			<td><?php echo $male_candidate; ?></td>
		</tr>
		<tr>
			<td>Total Candidate</td>
			<td><?php echo $total_candidate; ?></td>
		</tr>
		<tr>
			<td>Name Male</td>
			<td><?php echo $name_male; ?></td>
		</tr>
		<tr>
			<td>Eduksaun</td>
			<td><?php echo $edu_male; ?></td>
		</tr>
		<tr>
			<td>Birth P Male</td>
			<td><?php echo $birth_p_male; ?></td>
		</tr>
		<tr>
			<td>Birth D Male</td>
			<td><?php echo $birth_d_male; ?></td>
		</tr>
		<tr>
			<td>Address Male</td>
			<td><?php echo $address_male; ?></td>
		</tr>
		<tr>
			<td>Mobile Male</td>
			<td><?php echo $mobile_male; ?></td>
		</tr>
		<tr>
			<td>Email Male</td>
			<td><?php echo $email_male; ?></td>
		</tr>
		<!--<tr>
			<td>Valid Male</td>
			<td><?php echo $valid_male; ?></td>
		</tr>
		<tr>
			<td>Unvalid Male</td>
			<td><?php echo $unvalid_male; ?></td>
		</tr>-->
		<tr>
			<td>Name Female</td>
			<td><?php echo $name_female; ?></td>
		</tr>
		<tr>
			<td>Eduksaun</td>
			<td><?php echo $edu_female; ?></td>
		</tr>
		<tr>
			<td>Birth P Female</td>
			<td><?php echo $birth_p_female; ?></td>
		</tr>
		<tr>
			<td>Birth D Female</td>
			<td><?php echo $birth_d_female; ?></td>
		</tr>
		<tr>
			<td>Address Female</td>
			<td><?php echo $address_female; ?></td>
		</tr>
		<tr>
			<td>Mobile Female</td>
			<td><?php echo $mobile_female; ?></td>
		</tr>
		<tr>
			<td>Email Female</td>
			<td><?php echo $email_female; ?></td>
		</tr>
		<!--<tr>
			<td>Valid Female</td>
			<td><?php echo $valid_female; ?></td>
		</tr>
		<tr>
			<td>Unvalid Female</td>
			<td><?php echo $unvalid_female; ?></td>
		</tr>
		<tr>
			<td>Total Valid</td>
			<td><?php echo $total_valid; ?></td>
		</tr>
		<tr>
			<td>Total Unvalid</td>
			<td><?php echo $total_unvalid; ?></td>
		</tr>-->
		<tr>
			<td></td>
			<td><a href="<?php echo site_url('apftl_election') ?>" class="btn btn-default">Cancel</a></td>
		</tr>
	</table>
</div>