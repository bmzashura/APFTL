<div class="container-fluid">
    <h2 style="margin-top:0px">Apftl_program Read</h2>
    <table class="table">
        <tr>
            <td>Id Category</td>
            <td><?php echo $category; ?></td>
        </tr>
        <tr>
            <td>Activity</td>
            <td><?php echo $activity; ?></td>
        </tr>
        <tr>
            <td>Id Partner</td>
            <td><?php echo $partner; ?></td>
        </tr>
        <tr>
            <td>Date</td>
            <td><?php echo $date; ?></td>
        </tr>
        <tr>
            <td>Id Distric</td>
            <td><?php echo $distric; ?></td>
        </tr>
        <tr>
            <td>Description</td>
            <td><?php echo $description; ?></td>
        </tr>
        <tr>
            <td>Objective</td>
            <td><?php echo $objective; ?></td>
        </tr>
        <tr>
            <td>Participant M</td>
            <td><?php echo $participant_m; ?></td>
        </tr>
        <tr>
            <td>Participant F</td>
            <td><?php echo $participant_f; ?></td>
        </tr>
        <tr>
            <td>Participant Sum</td>
            <td><?php echo $participant_sum; ?></td>
        </tr>
        <tr>
            <td></td>
            <td><a href="<?php echo site_url('apftl_program') ?>" class="btn btn-default">Cancel</a></td>
        </tr>
    </table>
</div>