<div class="container-fluid">
    <h2 style="margin-top:0px">Member Detail </h2>
    <table class="table">
        <tr>
            <td>Photo</td>
            <td><?php echo $photo; ?></td>
        </tr>
        <tr>
            <td>F Name</td>
            <td><?php echo $f_name; ?></td>
        </tr>
        <tr>
            <td>L Name</td>
            <td><?php echo $l_name; ?></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td><?php echo $gender; ?></td>
        </tr>
        <tr>
            <td>Status</td>
            <td><?php echo $status; ?></td>
        </tr>
        <tr>
            <td>Birth P</td>
            <td><?php echo $birth_p; ?></td>
        </tr>
        <tr>
            <td>Birth D</td>
            <td><?php echo $birth_d; ?></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><?php echo $address; ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?php echo $email; ?></td>
        </tr>
        <tr>
            <td>Phone N</td>
            <td><?php echo $phone_n; ?></td>
        </tr>
        <tr>
            <td>Periodu</td>
            <td><?php echo $periodu; ?></td>
        </tr>
        <tr>
            <td></td>
            <td><a href="<?php echo site_url('apftl_member') ?>" class="btn btn-default">Cancel</a></td>
        </tr>
    </table>
</div>