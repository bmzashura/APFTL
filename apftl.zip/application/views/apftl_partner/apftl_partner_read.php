<div class="container-fluid">
    <h2 style="margin-top:0px">Partner Detail</h2>
    <table class="table">
        <tr>
            <td>Partner</td>
            <td><?php echo $partner; ?></td>
        </tr>
        <tr>
            <td></td>
            <td><a href="<?php echo site_url('apftl_partner') ?>" class="btn btn-default">Cancel</a></td>
        </tr>
    </table>
</div>